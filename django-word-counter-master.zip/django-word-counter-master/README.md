# django-word-counter

This Django project takes any text input, and displays the total word count as well as the frequency of each word, sorted in descending order.
